<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stylesDatosPasajero.css">
    <title>Detalles del Viaje</title>
</head>
<body>

<?php
// Verificar si se envió el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Datos de conexión a la base de datos
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "buses";

    // Crear conexión
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Verificar la conexión
    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    // Obtener datos del formulario
    $salida = $_POST["salida"];
    $regreso = $_POST["regreso"];
    $origen = $_POST["select"];
    $destino = $_POST["destino"];

    // Obtener la cantidad de pasajeros dinámicamente
    $numPasajeros = count($_POST["asiento"]);

    // Inicializar el total
    $total = 0;

    // Iterar sobre cada pasajero y sus datos
    for ($i = 1; $i <= $numPasajeros; $i++) {
        $nombre = $_POST["nombre$i"];
        $asiento = $_POST["asiento"][$i - 1];  // Obtener el asiento específico para este pasajero
        $categoria = "ADULTO";  // Puedes ajustar esto según tus necesidades
        $precio = 55.00;  // Puedes ajustar esto según tus necesidades

        // Sumar el precio al total
        $total += $precio;

        // Insertar datos en la base de datos
        $sql = "INSERT INTO pasajero_viaje (nombre, salida, regreso, origen, destino, asiento, categoria, precio) VALUES ";
        $sql .= "('$nombre', '$salida', '$regreso', '$origen', '$destino', '$asiento', '$categoria', $precio)";

        if ($conn->query($sql) !== TRUE) {
            echo "Error al insertar datos: " . $conn->error;
            // Puedes agregar una lógica adicional aquí si hay un error en la inserción
        }
    }

    // Mostrar los detalles del viaje y los pasajeros en una tabla
    echo "<h2>Detalles del Viaje</h2>";
    echo "<table>";
    echo "<tr><th>Salida</th><td>$salida</td></tr>";
    echo "<tr><th>Regreso</th><td>$regreso</td></tr>";
    echo "<tr><th>Origen</th><td>$origen</td></tr>";
    echo "<tr><th>Destino</th><td>$destino</td></tr>";
    echo "</table>";

    echo "<h2>Detalles de los Pasajeros</h2>";
    echo "<table>";
    echo "<tr><th>Nombre</th><th>Asiento</th><th>Categoría</th><th>Precio</th></tr>";
    for ($i = 1; $i <= $numPasajeros; $i++) {
        $nombre = $_POST["nombre$i"];
        $asiento = $_POST["asiento"][$i - 1];
        echo "<tr><td>$nombre</td><td>$asiento</td><td>ADULTO</td><td>$55.00</td></tr>";
    }
    echo "</table>";

    // Agregar campos para el método de pago
    echo "<div class='container'>";
    echo "<h2>Método de Pago</h2>";
    echo "<div class='user-details'>";
    echo "<form action='procesar_pago.php' method='post'>";

    echo "<div class='input-box'>";
    echo "<label for='numero_tarjeta'>Número de Tarjeta:</label>";
    echo "<input type='text' name='numero_tarjeta' id='numero_tarjeta' placeholder='Ingrese el número de tarjeta' required>";
    echo "</div>";

    echo "<div class='input-box'>";
    echo "<label for='cvv'>CVV:</label>";
    echo "<input type='text' name='cvv' id='cvv' placeholder='Ingrese el código CVV' required>";
    echo "</div>";

    echo "<div class='input-box'>";
    echo "<label for='fecha_expiracion'>Fecha de Expiración:</label>";
    echo "<input type='text' name='fecha_expiracion' id='fecha_expiracion' placeholder='MM/AA' required>";
    echo "</div>";

    echo "<div class='input-box'>";
    echo "<label for='propietario_tarjeta'>Propietario de la Tarjeta:</label>";
    echo "<input type='text' name='propietario_tarjeta' id='propietario_tarjeta' placeholder='Ingrese el nombre del propietario' required>";
    echo "</div>";


    echo "<br>";
    echo "<div class='button'>";
    echo "<input type='submit' name='realizar_pago' value='Realizar Pago'>";
    echo "</div>";

    echo "</div>";
    echo "</div>";
    echo "</form>";

    // Agregar formulario de PayPal
    echo "<h2>Paga con PayPal</h2>";
    echo "<div class='paypal-form'>";
    echo "<form action='https://www.paypal.com/cgi-bin/webscr' method='post' target='_top'>";
    echo "<input type='hidden' name='cmd' value='_s-xclick' />";
    echo "<input type='hidden' name='hosted_button_id' value='RSU8BP9Y2SUV2' />";
    echo "<input type='hidden' name='currency_code' value='MXN' />";
    echo "<input type='image' src='https://www.paypalobjects.com/es_XC/MX/i/btn/btn_paynowCC_LG.gif' border='0' name='submit' title='PayPal es una forma segura y fácil de pagar en línea.' alt='Comprar ahora'/>";
    echo "</form>";
    echo "</div>";
    // Cerrar conexión
    $conn->close();
}
?>
</body>
</html>
