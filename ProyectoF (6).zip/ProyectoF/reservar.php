<?php
// Conexión a la base de datos (ajusta las credenciales según tu configuración)
$servername = "localhost";
$username = "root";
$password = "";
$database = "test_db";

$conn = new mysqli($servername, $username, $password, $database);

// Verificar la conexión
if ($conn->connect_error) {
    die("Error en la conexión a la base de datos: " . $conn->connect_error);
}

// Recopilar datos de pasajeros del formulario
$nombre = $_POST['nombre'];
$correo = $_POST['correo'];
$telefono = $_POST['telefono'];
$fechaNacimiento = $_POST['fecha_nacimiento'];
$fechaSalida = $_POST['fecha_salida'];
$fechaRegreso = $_POST['fecha_regreso'];
$origen = $_POST['origen'];
$destino = $_POST['destino'];

// Insertar datos de pasajero en la base de datos
$sqlPasajero = "INSERT INTO pasajeros (nombre, correo, telefono, fecha_nacimiento, fecha_salida, fecha_regreso, origen, destino)
VALUES ('$nombre', '$correo', '$telefono', '$fechaNacimiento', '$fechaSalida', '$fechaRegreso', '$origen', '$destino')";

if ($conn->query($sqlPasajero) === TRUE) {
    $lastInsertId = $conn->insert_id; // Obtenemos el ID del pasajero que se acaba de insertar
} else {
    echo "Error al guardar los datos del pasajero: " . $conn->error;
    exit; // Puedes tomar medidas adicionales para manejar el error adecuadamente
}

// Recopilar datos de asientos seleccionados
$asientosSeleccionados = isset($_POST['asientos']) ? $_POST['asientos'] : [];

// Insertar datos de asientos en la base de datos
foreach ($asientosSeleccionados as $asiento) {
    $sqlAsientos = "INSERT INTO asientos (id_pasajero, numero_asiento) VALUES ('$lastInsertId', '$asiento')";
    if ($conn->query($sqlAsientos) !== TRUE) {
        echo "Error al guardar los datos de los asientos: " . $conn->error;
        exit; // Puedes tomar medidas adicionales para manejar el error adecuadamente
    }
}

// Cerrar la conexión a la base de datos
$conn->close();
?>
