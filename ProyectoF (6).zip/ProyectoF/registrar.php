<?php
    include("conexion.php");

    if(isset($_POST['register'])){
        if(
            strlen($_POST['usuario'])>=1 &&
            strlen($_POST['correo'])>=1 &&
            strlen($_POST['telefono'])>=1 &&
            strlen($_POST['password'])>=1
            ){
                $username=trim($_POST['usuario']);
                $correo=trim($_POST['correo']);
                $telefono=trim($_POST['telefono']);
                $contra=trim($_POST['password']);
                $fecha= date("d/m/y");
                $consulta="INSERT INTO datos(usuario,correo,telefono,contra,fecha)
                            VALUES('$username','$correo','$telefono','$contra','$fecha')";
                $resultado=mysqli_query($conex,$consulta);
                if($resultado){
                ?>
                    <h3 class="success" id="successMessage">Tu registro se ha completado</h3>
                <?php
                }else{
                 ?>
                    <h3 class="error" id="errorMessage">Ocurrió un error</h3>
                 <?php
                }    
            }else{
            ?>
             <h3 class="error" id="llena"> Llena todos los campos</h3>
            <?php
        }
    }
?>
<script>
    // Función para ocultar los mensajes después de un tiempo determinado
    setTimeout(function() {
        var successMessage = document.getElementById("successMessage");
        if (successMessage) {
            successMessage.style.display = "none";
        }
        var errorMessage = document.getElementById("errorMessage");
        if (errorMessage) {
            errorMessage.style.display = "none";
        }
        
        var llenar = document.getElementById("llena");
        if (llenar) {
           llenar.style.display = "none";
        }
    }, 5000); // 5000 milisegundos = 5 segundos (puedes ajustar este valor)
</script>
