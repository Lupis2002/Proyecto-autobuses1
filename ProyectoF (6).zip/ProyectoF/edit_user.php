<?php

include("db_conn.php");

$id=$_POST["id"];
$username = $_POST['username'];
$correo = $_POST['correo'];
$telefono = $_POST['telefono'];
$password = $_POST['contra'];
$fecha = $_POST['fecha'];


$sql="UPDATE datos SET username='$username',
                        correo='$correo', 
                        telefono ='$telefono',
                        contra='$password', 
                        fecha='$fecha' 
                        WHERE id='$id'";
$query = mysqli_query($conn, $sql);

if ($query) {
    header("Location: listaUsuarios.php");
} else {
    echo "Error al actualizar el usuario: " . mysqli_error($conn);
}

?>