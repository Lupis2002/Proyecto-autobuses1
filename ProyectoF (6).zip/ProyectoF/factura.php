<?php
require('fpdf.php');

class PDF extends FPDF
{
    function Header()
    {
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(100);
        $this->Cell(0, 10, utf8_decode('Boleto de Camión'), 0, 1, 'C');
        $this->Ln(10);

        // Restablecer colores de fondo y texto
        $this->SetFillColor(255);
        $this->SetTextColor(0);

    }


// Restablecer colores de fondo y texto



    function ChapterTitle($title)
    {
        $this->SetFillColor(46, 161, 255); // Color de fondo
        $this->SetTextColor(0); // Color del texto
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(0, 6, $title, 0, 1, 'L', 1);
        $this->Ln(5);

        // Restablecer colores de fondo y texto
        $this->SetFillColor(255);
        $this->SetTextColor(0);
    }

    function ChapterBody($body)
    {
        $this->SetFont('Arial', '', 10);
        $this->MultiCell(0, 10, $body);
    }

    function ChapterTable($header, $data)
    {
        // Cabecera
        $this->SetFont('Arial', 'B', 10);
        foreach ($header as $col) {
            $this->Cell(45, 10, $col, 1);
        }
        $this->Ln();

        // Datos
        $this->SetFont('Arial', '', 10);
        foreach ($data as $row) {
            foreach ($row as $col) {
                $this->Cell(45, 10, $col, 1);
            }
            $this->Ln();
        }
    }
}

// Crear instancia de PDF
// Crear instancia de PDF
$pdf = new PDF();
$pdf->AddPage();

// Establecer colores de fondo y texto para la información del boleto
$pdf->SetFillColor(46, 161, 255); // Color de fondo
$pdf->SetTextColor(0); // Color del texto
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(60, 10, 'Numero de Boleto', 1, 0, 'C', 1);
$pdf->Cell(60, 10, 'Origen', 1, 0, 'C', 1);
$pdf->Cell(60, 10, 'Destino', 1, 1, 'C', 1);

require 'conexion.php';
// Obtener información de viajes desde la base de datos
$consulta = "SELECT * FROM viajes";
$resultado = $mysqli->query($consulta);

while ($row = $resultado->fetch_assoc()) {
    // Usar los datos de la base de datos en las celdas
    $pdf->Cell(60, 10, $row['id_viaje'], 1, 0, 'C');
    $pdf->Cell(60, 10, utf8_decode($row['origen']), 1, 0, 'C');
    $pdf->Cell(60, 10, utf8_decode($row['destino']), 1, 1, 'C');
}


// Detalle del Boleto con tabla
$pdf->ChapterTitle('Detalle del Boleto');
$header = array(utf8_decode('Descripción'), 'Precio');
$data = array(
    array(utf8_decode('Boleto de Camión'), '$500.00'),
);
$pdf->ChapterTable($header, $data);

// Resumen de la Factura con tabla
$pdf->ChapterTitle('Resumen de la Factura');
$header = array('Concepto', 'Monto');
$data = array(
    array('Subtotal', '$500.00'),
    array('Impuesto (10%)', '$50.00'),
    array('Total', '$550.00'),
);
$pdf->ChapterTable($header, $data);

$pdf->ChapterTitle('Datos del Cliente');
$header = array('Concepto', 'Monto');
$data = array(
    array('Subtotal', '$500.00'),
    array('Impuesto (10%)', '$50.00'),
    array('Total', '$550.00'),
);

//$clienteID = $_POST['id'];
$consulta = "SELECT*FROM reserva WHERE  id=2";
$resultado = $mysqli->query($consulta);

while ($row = $resultado->fetch_assoc()) {
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10,  utf8_decode('Información de Reserva'), 0, 1);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(0, 10, 'Nombre Completo: ' . utf8_decode($row['nombre_com']), 0, 1);
    $pdf->Cell(0, 10,  utf8_decode('Correo Electrónico: ') . $row['correo'], 0, 1);
    $pdf->Cell(0, 10,  utf8_decode('Teléfono: ') . $row['telefono'], 0, 1);
    $pdf->Cell(0, 10, 'Fecha de Nacimiento: ' . $row['fech_nac'], 0, 1);
    $pdf->Cell(0, 10, 'Fecha de Salida: ' . $row['fecha_sal'], 0, 1);
    $pdf->Cell(0, 10, 'Fecha de Registro: ' . $row['fecha_reg'], 0, 1);
    $pdf->Cell(0, 10, 'Origen: ' . utf8_decode($row['origen']), 0, 1);
    $pdf->Cell(0, 10, 'Destino: ' . utf8_decode($row['destino']), 0, 1);
    $pdf->Cell(0, 10,  utf8_decode('Número de Asiento: ') . $row['asiento'], 0, 1);
    $pdf->Ln(10); // Espacio en blanco entre registros
}

// Datos del Cliente con tabla


// Salvar el PDF en un archivo o mostrarlo en el navegador
$pdf->Output();
?>
