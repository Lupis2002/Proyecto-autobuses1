<?php
    $conex=mysqli_connect("localhost","root","","test_db");
    //$mysqli = new mysqli("localhost","root","","test_db");
?>