<?php
include("db_conn.php");
$id=$_GET['id'];
$sql= "DELETE FROM datos WHERE id='$id'";
$query=mysqli_query($conn,$sql);
if ($query) {
    header("Location: listaUsuarios.php");
} else {
    echo "Error al eliminar el usuario: " . mysqli_error($conn);
}

?>
